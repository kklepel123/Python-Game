import math, random
from livewires import games

games.init(screen_width = 640, screen_height = 480, fps = 50)

class Player(games.Sprite):
    """ The player's player. """
    waitTime = 50
    waitCounter = 0
    canShoot = True
    def update(self):
        """ Rotate based on left and right arrow keys. """
        if games.keyboard.is_pressed(games.K_RIGHT):
            self.angle += 1
        if games.keyboard.is_pressed(games.K_LEFT):
            self.angle -= 1

        """ Move based on up and down arrow keys. """    
        if games.keyboard.is_pressed(games.K_UP) and self.y > 50:
            self.y -= 3
        if games.keyboard.is_pressed(games.K_DOWN) and self.y < 430:
            self.y += 3

        """ Fire missile if spacebar pressed and missile wait is over. """    
        if games.keyboard.is_pressed(games.K_SPACE) and Player.canShoot == True:
            newBullet = Bullet(self.x, self.y, self.angle + 90)
            games.screen.add(newBullet)
            Player.canShoot = False
            Player.waitCounter = 0
        if Player.canShoot == False:
            Player.waitCounter += 1.5
        if Player.waitCounter >= Player.waitTime:
            Player.canShoot = True
            
class Bullet(games.Sprite):
    """ A bullet shot from the player's player. """
    image = games.load_image("bullet.png")
    VELOCITY_FACTOR = 7

    """ Fire bullet from certain position based on the angle of Player. """
    def __init__(self, playerX, playerY, playerAngle):
        angle = playerAngle * math.pi / 180
        if playerAngle == 90:
            y = playerY + 35
            x = playerX + 70
        elif 450 >= playerAngle > 430:
            y = playerY + 25
            x = playerX + 70
        elif 430 >= playerAngle > 410:
            y = playerY + 10
            x = playerX + 70
        elif 410 >= playerAngle > 390:
            y = playerY - 5
            x = playerX + 70
        elif 390 >= playerAngle > 360:
            y = playerY - 20
            x = playerX + 40
        if 90 < playerAngle <= 110:
            y = playerY + 35
            x = playerX + 65
        elif 110 < playerAngle <= 130:
            y = playerY + 45
            x = playerX + 60
        elif 130 < playerAngle <= 150:
            y = playerY + 55
            x = playerX + 40
        elif 150 < playerAngle <= 180:
            y = playerY + 50
            x = playerX + 15
        if 360 >= playerAngle > 180:
            y = playerY + 35
            x = playerX 
        dx = Bullet.VELOCITY_FACTOR * math.sin(angle)
        dy = Bullet.VELOCITY_FACTOR * -math.cos(angle)

        super(Bullet, self).__init__(image = Bullet.image, x = x, y = y, dx = dx, dy = dy)

    def update(self):
        if self.x > games.screen.width + 100:
            self.destroy()

        """ Destroy piranha and bullet when they collide. """
        if self.overlapping_sprites:
            for sprite in self.overlapping_sprites:
                sprite.destroy()
            """ Blood explosion. """
            newExplosion = Explosion(x = self.x + 70, y = self.y)
            games.screen.add(newExplosion)
            self.destroy()
            
class Piranha(games.Sprite):
    """ Initializes piranha sprite. """
    def __init__(self, image, x, y, dx, dy):
        super(Piranha, self).__init__(image = image, x = x, y = y, dx = dx, dy = dy)
    
    def update(self):
        self.x -= 1    
        if self.x <= 100:
            self.x = 100
            
class Explosion(games.Animation):
    """ Explosion animation. """
    bloodExplosionFiles = ["bloodexplosion1.jpg",
                   "bloodexplosion2.jpg",
                   "bloodexplosion3.jpg",
                   "bloodexplosion4.jpg",]

    def __init__(self, x, y):
        super(Explosion, self).__init__(images = Explosion.bloodExplosionFiles,
                                        x = x, y = y,
                                        repeat_interval = 6, n_repeats = 1,
                                        is_collideable = False)

def main():
    """ Establish background. """
    wallImage = games.load_image("waterbackground.jpg", transparent = False)
    games.screen.background = wallImage

    """ Create dock. """
    dockImage = games.load_image("dock.gif")
    dock = games.Sprite(image = dockImage, x = 0, y = 240, is_collideable = False)
    games.screen.add(dock)

    """ Create the player. """
    playerImage = games.load_image("playerImage.jpg")
    player = Player(image = playerImage, x = 45, y = 240, is_collideable = False)
    games.screen.add(player)

    """ Create 20 piranhas. """
    for i in range(25):
        x = random.randint(700, 3000)
        y = random.randint(20, 460)
        piranhaImage = games.load_image("piranha.jpg")
        piranha = Piranha(image = piranhaImage, x = x, y = y, dx = -.25, dy = 0)
        games.screen.add(piranha)

    games.screen.mainloop()

""" Kick it off! """
main()
